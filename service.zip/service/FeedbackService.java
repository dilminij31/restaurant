package com.Restaurant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Restaurant.model.Feedback;

import com.Restaurant.repository.FeedbackRepository;

@Service
public class FeedbackService {
	
	@Autowired
	private FeedbackRepository fRepo;
	
	public void save(Feedback feedback) {
		fRepo.save(feedback);
	}
	
	public List<Feedback> getAllFeedback(){
		return fRepo.findAll();
	}
	
	public Feedback getFeedbackById(int id) {
		return fRepo.findById(id).get();
	}
	
	public void deleteById(int id) {
		fRepo.deleteById(id);
	}
}
