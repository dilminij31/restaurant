package com.Restaurant.service;

import com.Restaurant.dto.UserDto;
import com.Restaurant.model.User;

public interface UserService {
	
	User save(UserDto userDto);
	

	
	
}
