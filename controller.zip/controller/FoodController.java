package com.Restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Restaurant.model.Food;
import com.Restaurant.model.User;
import com.Restaurant.service.FoodService;

import com.Restaurant.service.UserServiceImpl;

@Controller
public class FoodController {
	
	@Autowired
	private FoodService service;
	@Autowired
	private UserServiceImpl uService;
	
	@GetMapping("food_register")
	public String foodRegister() {
		return "foodRegister";
	}
	
	@GetMapping("food_list")
	public ModelAndView getAllFood() {
		List<Food>list=service.getAllFood();
		
		return new ModelAndView("foodList","food",list);
	}
	
	@PostMapping("/save")
	public String addFood(@ModelAttribute Food f) {
		service.save(f);
		return "redirect:/food_list";
	}

	@GetMapping("user_list")
	public ModelAndView getAllUser() {
		List<User>list=uService.getAllUser();
		
		return new ModelAndView("userList","user",list);
	}
	
	@GetMapping("user_food")
	public ModelAndView getAllUserFood() {
		List<Food>list=service.getAllFood();
		
		return new ModelAndView("user/userFood","food",list);
	}
	
	@GetMapping("about_page")
	public String about() {
		return "user/about";
	}
	
	@GetMapping("staff_food")
	public ModelAndView getAllStaffFood() {
		List<Food>list=service.getAllFood();
		
		return new ModelAndView("staff/staffFood","food",list);
	}
	
	@RequestMapping("/editFood/{id}")
	public String editFood(@PathVariable("id") int id,Model model){
		Food f=service.getFoodById(id);
		model.addAttribute("food",f);
		return "foodEdit";
	}
	
	
	
	@RequestMapping("/deleteFood/{id}")
	public String deletFood(@PathVariable("id")int id) {
		service.deleteById(id);
		return "redirect:/admin-page";
	}
	
	@RequestMapping("/editUser/{id}")
	public String editUser(@PathVariable("id") Long id,Model model)
	{
		User user=service.getUserById(id);
		model.addAttribute("user",user);
		return "userEdit";
	}
	
	@RequestMapping("/deleteUser/{id}")
	public String deletUser(@PathVariable("id")Long id) {
		service.deleteById(id);
		return "redirect:/admin-page";
	}
	
}
