package com.Restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Restaurant.model.Feedback;
import com.Restaurant.service.FeedbackService;

@Controller
public class FeedbackController {
	
	@Autowired
	private FeedbackService feedbackService;
	
	@GetMapping("/feedback")
	public String feedbackForm() {
		return "user/feedback";
	}
	
	@PostMapping("/fSave")
	public String addFeedback(@ModelAttribute Feedback feedback) {
		feedbackService.save(feedback);
		return "redirect:/user-page";
	}
	
	@GetMapping("feedback_list")
	public ModelAndView feedbackList() {
		List<Feedback>list=feedbackService.getAllFeedback();
		return new ModelAndView ("user/feedbackUser","feedback",list);
	}
	
	@GetMapping("feedback_staff")
	public ModelAndView feedbackStaff() {
		List<Feedback>list=feedbackService.getAllFeedback();
		return new ModelAndView ("staff/feedbackList","feedback",list);
	}
	
	@RequestMapping("/editFeedback/{id}")
	public String editFeedback(@PathVariable("id") int id,Model model) {
		Feedback feedback=feedbackService.getFeedbackById(id);
		model.addAttribute("feedback",feedback);
		return "staff/feedbackEdit";
	}
	@PostMapping("/ffSave")
	public String addFeedbackstaff(@ModelAttribute Feedback feedback) {
		feedbackService.save(feedback);
		return "redirect:/staff-page";
	}
	
	@RequestMapping("/deleteFeedback/{id}")
	public String deleteFeedback(@PathVariable("id")int id) {
		feedbackService.deleteById(id);
		return "redirect:/feedback_staff";
	}
	
	@RequestMapping("/deleteFeedbackUser/{id}")
	public String deleteFeedbackUser(@PathVariable("id")int id) {
		feedbackService.deleteById(id);
		return "redirect:/feedback_list";
	}
}
