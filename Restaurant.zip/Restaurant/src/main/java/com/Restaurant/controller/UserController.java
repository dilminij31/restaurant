package com.Restaurant.controller;

import java.security.Principal;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;


import com.Restaurant.dto.UserDto;

import com.Restaurant.service.UserService;



@Controller
public class UserController {
	
	@Autowired
	UserDetailsService userDeatilsService;
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/registration")
	public String getRegistrationPage(@ModelAttribute("user") UserDto userDto) {
		return "register";
	}
	
	@PostMapping("/registration")
	public String saveUSer(@ModelAttribute("user") UserDto userDto,Model model) {
		userService.save(userDto);
		model.addAttribute("message","Registered Successfully");
		return "register";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("user-page")
	public String userPage(Model model,Principal principal) {
		UserDetails userDetails = userDeatilsService.loadUserByUsername(principal.getName());
		model.addAttribute("user",userDetails);
		return "user";
	}
	
	@GetMapping("admin-page")
	public String adminPage(Model model,Principal principal) {
		UserDetails userDetails = userDeatilsService.loadUserByUsername(principal.getName());
		model.addAttribute("user",userDetails);
		return "admin";
	}
	
	@GetMapping("staff-page")
	public String staffPage(Model model,Principal principal) {
		UserDetails userDetails = userDeatilsService.loadUserByUsername(principal.getName());
		model.addAttribute("user",userDetails);
		return "staff";
	}

	
}
