package com.Restaurant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Restaurant.model.Food;
import com.Restaurant.model.User;
import com.Restaurant.repository.FoodRepository;
import com.Restaurant.repository.UserRepository;

@Service
public class FoodService {
	
	@Autowired
	private FoodRepository fRepo;
	
	@Autowired
	private UserRepository userRepository;
	
	
	public void save(Food f) {
		fRepo.save(f);
	}
	
	public List<Food> getAllFood(){
		return fRepo.findAll();
	}
	
	public Food getFoodById(int id) {
		return fRepo.findById(id).get();
	}
	
	public void deleteById(int id) {
		fRepo.deleteById(id);
	}
	
	public User getUserById(Long id) {
		return userRepository.findById((long) id).get();
	}
	public void deleteById(Long id) {
		userRepository.deleteById(id);
	}
}
